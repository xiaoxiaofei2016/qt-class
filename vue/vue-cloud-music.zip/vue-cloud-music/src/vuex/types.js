export const COM_SHOW_SIDE_BAR = 'COM_SHOW_SIDE_BAR' // 侧边栏菜单
export const SET_FULL_SCREEN = 'SET_FULL_SCREEN' // 设置播放页面是否全屏展示
export const SET_PLAY_LIST = 'SET_PLAY_LIST' // 播放列表
export const SET_CURRENT_INDEX = 'SET_CURRENT_INDEX' // 设置播放音乐的索引
export const SET_PLAYING = 'SET_PLAYING'

export const CHANGE_HOME_DATA = 'home/CHANGE_HOME_DATA'

# es module
## 命名導出 
export const sdfg
import { sdfg } = '.js'
## 默認導出
export default 
import .. from '.js'

- jspang.com MVVM
 1. SEO很重要 ssr next.js  nuxt.js
 2. MVVM 路由
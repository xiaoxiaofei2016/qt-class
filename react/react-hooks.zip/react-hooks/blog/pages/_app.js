import App from 'next/app'

import 'antd/dist/antd.css'
import '../static/style/pages/common.css'

export default App

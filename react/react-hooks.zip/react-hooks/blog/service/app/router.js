module.exports = app => {
  require('./router/default')(app)
}
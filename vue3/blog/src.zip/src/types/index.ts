// 导航 nav
export interface NavListItem {
  index: string,
  path: string,
  name: string
}
